
exports.webexTeams = (req, res) => {
  console.log(req)
};